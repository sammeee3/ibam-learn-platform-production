export default function Test() { 
  return (
    <div style={{backgroundColor: 'red', color: 'white', padding: '16px'}}>
      INLINE STYLE TEST
    </div>
  ); 
}