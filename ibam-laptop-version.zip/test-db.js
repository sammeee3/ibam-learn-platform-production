console.log("Testing database connection...")
fetch("https://tutrnikhomrgcpkzszvq.supabase.co/rest/v1/profiles?select=count", {
  headers: {"apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR1dHJuaWtob21yZ2Nwa3pzenZxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg5ODk0MTksImV4cCI6MjA2NDU2NTQxOX0.-TI2kjnGM27QYM0BfBSogGf8A17VRxNlydoRYmnGmn8"}
}).then(r => r.json()).then(console.log).catch(console.error)
