export default function LoginTest() {
  return (
    <div style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>🔓 Auth-Free Login Test</h1>
      <p>This page has NO authentication logic!</p>
      <p>If you see this, we bypassed the redirect!</p>
      <a href="/test">Back to Test Page</a>
    </div>
  );
}
