export default function DashboardTest() {
  return (
    <div style={{padding: "40px"}}>
      <h1>Auth-Free Dashboard</h1>
      <p>SUCCESS! No redirects here!</p>
      <a href="/test">Back to Test</a>
    </div>
  );
}
